/**
 * 
 */
/**
 * @author ProSet
 *
 */
module first_week_project {
	requires java.se;
}